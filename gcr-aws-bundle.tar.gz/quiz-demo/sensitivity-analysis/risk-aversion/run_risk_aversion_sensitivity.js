/**
 * Risk aversion sensitivity analysis.
 *
 * For each test in combinations.json, runs two allocations:
 *   baseline:     worldviews with risk profiles from the test's "baseline" map
 *   new_version:  same worldviews + credences, risk profiles from "new_version" map
 *
 * Approach is selectable via --approach: weighted (credence-weighted average) or
 * staged (sequential staged allocation); weighted runs when --approach is omitted.
 *
 * Each test's worldview keys are matched BY id to sa_specialBlend.json (verified
 * against production specialBlend.json), so risk profiles attach to the right
 * worldview by name — not by array position.
 *
 * Outputs (outputs/ directory):
 *   fund/neutral_baseline_allocation.csv       — all-neutral reference allocation
 *   fund/risk_aversion_summary.csv             — one row per test: SI + per-fund deltas
 *   cause/risk_aversion_cause_area_summary.csv — per test: cause-area SI + deltas
 *
 * Usage:
 *   node run_risk_aversion_sensitivity.js
 *   node run_risk_aversion_sensitivity.js --test specialblend_to_combined
 *   node run_risk_aversion_sensitivity.js --dry-run
 *   node run_risk_aversion_sensitivity.js --base PATH/to/dataset.json
 *   node run_risk_aversion_sensitivity.js --approach staged
 */

import { fileURLToPath } from 'url';
import { join, dirname } from 'path';
import { mkdirSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = join(__dirname, '..', '..');

import { computeMultiStageAllocation } from '../../src/utils/marcusCalculation.js';
import { computeWeightedAllocation } from '../computeWeightedAllocation.js';
import {
  loadJson,
  loadSaWorldviews,
  loadDataset,
  pickDefaultDataset,
  rankDict,
  writeCsv,
  parseArgs,
  checkDrCeilings,
  groupByCauseArea,
} from '../sensitivity_utils.js';

const OUTPUT_DIR = join(__dirname, 'outputs');
const FUND_DIR = join(OUTPUT_DIR, 'fund');
const CAUSE_DIR = join(OUTPUT_DIR, 'cause');

// ---------------------------------------------------------------------------
// Parse args — extends sensitivity_utils.parseArgs with --test
// ---------------------------------------------------------------------------

const args = parseArgs(process.argv);
const testArgIdx = process.argv.indexOf('--test');
const testFilter = testArgIdx !== -1 ? process.argv[testArgIdx + 1] : null;

// ---------------------------------------------------------------------------
// Load inputs
// ---------------------------------------------------------------------------

const { tests, risk_codes } = loadJson(join(__dirname, 'combinations.json'));
const sbWvs = loadSaWorldviews(REPO_ROOT);

const { projects, incrementSize, drStepSize } = loadDataset(
  args.base ?? pickDefaultDataset(REPO_ROOT)
);
const { stages } = loadJson(join(__dirname, '..', 'baseline.json'));
const totalBudget = stages.reduce((s, st) => s + st.budget, 0);
const fundIds = Object.keys(projects).sort();
const isWeighted = args.approach !== 'staged'; // weighted unless staged is explicitly requested
const methodEntries = stages.map((s) => ({
  jsKey: s.method,
  weight: s.budget / totalBudget,
  options: s.options ?? {},
}));

// Only run tests that are fully populated (have both baseline and new_version)
const activeTests = Object.entries(tests).filter(
  ([name, body]) =>
    (!testFilter || name === testFilter) &&
    body &&
    typeof body === 'object' &&
    body.baseline &&
    body.new_version
);

if (testFilter && activeTests.length === 0) {
  const available = Object.keys(tests).join(', ');
  throw new Error(`No test named "${testFilter}". Available: ${available}`);
}

console.log('\nRisk aversion sensitivity analysis');
console.log(`  Worldviews:  ${sbWvs.length} (sa_specialBlend.json)`);
console.log(`  Funds:       ${fundIds.length}`);
console.log(`  Increment:   $${incrementSize}M,  drStepSize: $${drStepSize}M`);
console.log(`  Budget:      $${totalBudget}M`);
console.log(`  Approach:    ${isWeighted ? 'weighted-average' : 'staged'}`);
console.log(
  `  Tests:       ${activeTests.length}${testFilter ? ` (filtered to: ${testFilter})` : ''}`
);
console.log(
  `  Risk codes:  ${Object.entries(risk_codes)
    .map(([k, v]) => `${k}=${v}`)
    .join(', ')}`
);

if (args.dryRun) {
  for (const [name, test] of activeTests) {
    const wvNames = Object.keys(test.baseline);
    const changedCount = wvNames.filter((n) => test.baseline[n] !== test.new_version[n]).length;
    console.log(`\n  Test: ${name}  (${changedCount}/${wvNames.length} profiles change)`);
    for (const wvName of wvNames) {
      const from = test.baseline[wvName];
      const to = test.new_version[wvName];
      const arrow = from === to ? '  (unchanged)' : `  ${from} → ${to}`;
      console.log(`    ${wvName.slice(0, 60).padEnd(60)}${arrow}`);
    }
  }
  process.exit(0);
}

// ---------------------------------------------------------------------------
// Helper: clone worldviews with overridden risk profiles
// ---------------------------------------------------------------------------

function buildWorldviews(test, versionKey) {
  const riskMap = test[versionKey];
  // Match BY id (not array position): each worldview's risk profile comes from the
  // test entry keyed by that worldview's sa_specialBlend id.
  return sbWvs.map((wv) => {
    const label = riskMap[wv.id];
    if (label === undefined) {
      throw new Error(`Test "${versionKey}" has no entry for worldview id "${wv.id}"`);
    }
    if (!(label in risk_codes)) {
      throw new Error(`Unknown risk label "${label}" in ${versionKey} — not in risk_codes`);
    }
    return { ...wv, risk_profile: risk_codes[label] };
  });
}

// ---------------------------------------------------------------------------
// Helper: run allocation and return { allocations, funding }
// ---------------------------------------------------------------------------

function runAlloc(worldviews) {
  if (isWeighted) {
    return computeWeightedAllocation(
      projects,
      worldviews,
      methodEntries,
      totalBudget,
      incrementSize,
      { drStepSize }
    );
  }
  return computeMultiStageAllocation(
    projects,
    worldviews,
    stages,
    incrementSize,
    undefined,
    drStepSize
  );
}

// ---------------------------------------------------------------------------
// Neutral baseline — all worldviews at risk_profile 0, specialBlend credences
// Saved as a standalone CSV for manual verification.
// ---------------------------------------------------------------------------

console.log(`\n${'='.repeat(60)}`);
console.log('Computing neutral baseline (all worldviews risk_profile=0)...');

const neutralWvs = sbWvs.map((wv) => ({ ...wv, risk_profile: 0 }));
const { allocations: neutralAlloc, funding: neutralFunding } = runAlloc(neutralWvs);
const neutralRanks = rankDict(neutralAlloc);
checkDrCeilings(projects, incrementSize, neutralFunding, 'neutral_baseline');

const neutralRows = fundIds
  .slice()
  .sort((a, b) => neutralAlloc[b] - neutralAlloc[a])
  .map((fid) => ({
    fund: fid,
    allocation_pct: neutralAlloc[fid].toFixed(2),
    funding_M: neutralFunding[fid].toFixed(2),
    rank: neutralRanks[fid],
  }));

for (const r of neutralRows) {
  const bar = '█'.repeat(Math.round((neutralAlloc[r.fund] / 100) * 40));
  console.log(
    `  ${String(r.rank).padStart(2)}. ${r.fund.padEnd(32)} ${r.allocation_pct.padStart(5)}%  $${r.funding_M.padStart(6)}M  ${bar}`
  );
}

mkdirSync(FUND_DIR, { recursive: true });
mkdirSync(CAUSE_DIR, { recursive: true });

writeCsv(
  join(FUND_DIR, 'neutral_baseline_allocation.csv'),
  ['fund', 'allocation_pct', 'funding_M', 'rank'],
  neutralRows
);

// ---------------------------------------------------------------------------
// Run tests
// ---------------------------------------------------------------------------

const summaryRows = [];
const causeSummaryRows = [];
const caKeys = ['ghd', 'gcr', 'aw'];
let drChecksPassed = true;
let drCheckCount = 0;

for (const [testName, test] of activeTests) {
  console.log(`\n${'='.repeat(60)}`);
  console.log(`Test: ${testName}`);

  const wvNames = Object.keys(test.baseline);
  const changedCount = wvNames.filter((n) => test.baseline[n] !== test.new_version[n]).length;
  console.log(`  Profiles changed: ${changedCount}/${wvNames.length}`);

  const baseWvs = buildWorldviews(test, 'baseline');
  const newWvs = buildWorldviews(test, 'new_version');

  process.stdout.write('  baseline    ');
  const { allocations: baseAlloc, funding: baseFunding } = runAlloc(baseWvs);
  const topBase = fundIds.reduce((a, b) => (baseAlloc[a] > baseAlloc[b] ? a : b));
  console.log(`top: ${topBase} (${baseAlloc[topBase].toFixed(1)}%)`);

  drChecksPassed &&= checkDrCeilings(projects, incrementSize, baseFunding, `${testName}/baseline`);
  drCheckCount++;

  process.stdout.write('  new_version ');
  const { allocations: newAlloc, funding: newFunding } = runAlloc(newWvs);
  const topNew = fundIds.reduce((a, b) => (newAlloc[a] > newAlloc[b] ? a : b));
  console.log(`top: ${topNew} (${newAlloc[topNew].toFixed(1)}%)`);

  drChecksPassed &&= checkDrCeilings(
    projects,
    incrementSize,
    newFunding,
    `${testName}/new_version`
  );
  drCheckCount++;

  const si = fundIds.reduce((s, f) => s + Math.abs(newAlloc[f] - baseAlloc[f]), 0) / 2;
  console.log(`  SI=${si.toFixed(4)}pp`);

  // Cause-area allocations + cause-area SI
  const baseCA = groupByCauseArea(baseAlloc);
  const newCA = groupByCauseArea(newAlloc);
  const siCA = caKeys.reduce((s, ca) => s + Math.abs(newCA[ca] - baseCA[ca]), 0) / 2;

  // Summary row
  const summaryRow = {
    test: testName,
    sensitivity_index: si.toFixed(4),
    ca_sensitivity_index: siCA.toFixed(4),
  };
  for (const fid of fundIds) {
    summaryRow[`${fid}_delta`] = (newAlloc[fid] - baseAlloc[fid]).toFixed(2);
  }
  summaryRows.push(summaryRow);

  // Cause-area summary row
  const mostAffCA = caKeys.reduce((a, b) =>
    Math.abs(newCA[a] - baseCA[a]) > Math.abs(newCA[b] - baseCA[b]) ? a : b
  );
  const causeSummaryRow = {
    test: testName,
    sensitivity_index: siCA.toFixed(4),
    most_affected_cause: mostAffCA,
    most_affected_delta: (newCA[mostAffCA] - baseCA[mostAffCA]).toFixed(2),
  };
  for (const ca of caKeys) {
    causeSummaryRow[`${ca}_base`] = baseCA[ca].toFixed(2);
    causeSummaryRow[`${ca}_new`] = newCA[ca].toFixed(2);
    causeSummaryRow[`${ca}_delta`] = (newCA[ca] - baseCA[ca]).toFixed(2);
  }
  causeSummaryRows.push(causeSummaryRow);
}

// ---------------------------------------------------------------------------
// Print summary ranked by SI
// ---------------------------------------------------------------------------

summaryRows.sort((a, b) => parseFloat(b.sensitivity_index) - parseFloat(a.sensitivity_index));

console.log(`\n${'='.repeat(60)}`);
console.log('Summary (ranked by sensitivity index):');
for (const r of summaryRows) {
  console.log(
    `  ${r.test.padEnd(45)}  SI=${r.sensitivity_index}pp  caSI=${r.ca_sensitivity_index}pp`
  );
}

// ---------------------------------------------------------------------------
// Write CSVs
// ---------------------------------------------------------------------------

const summaryFields = [
  'test',
  'sensitivity_index',
  'ca_sensitivity_index',
  ...fundIds.map((f) => `${f}_delta`),
];
writeCsv(join(FUND_DIR, 'risk_aversion_summary.csv'), summaryFields, summaryRows);

causeSummaryRows.sort((a, b) => parseFloat(b.sensitivity_index) - parseFloat(a.sensitivity_index));
writeCsv(
  join(CAUSE_DIR, 'risk_aversion_cause_area_summary.csv'),
  [
    'test',
    'sensitivity_index',
    'most_affected_cause',
    'most_affected_delta',
    ...caKeys.flatMap((ca) => [`${ca}_base`, `${ca}_new`, `${ca}_delta`]),
  ],
  causeSummaryRows
);

console.log(
  `\nDR ceiling tests: ${drChecksPassed ? `PASS (${drCheckCount} scenarios checked)` : 'FAIL — see errors above'}`
);
if (!drChecksPassed) process.exit(1);
