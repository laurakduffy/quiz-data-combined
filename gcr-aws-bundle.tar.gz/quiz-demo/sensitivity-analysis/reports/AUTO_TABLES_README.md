# Auto-updating the report's sensitivity tables

`update_report_tables.py` rebuilds the presentation tables in the Fund-Level
Sensitivity Analysis report straight from the raw SI CSVs, so you don't have to
hand-clean the outputs every time a model is re-run.

Each report table is described once in the `TABLE_SPECS` dictionary at the bottom
of the script (the "dictionary that maps tables to files"). On every run the
script recomputes the numbers from the live CSVs while keeping your editorial
labels, then either updates the table inside a **copy** of the report or emits a
standalone table to paste in.

The columns it produces match the report style:

| Scenario | Total portfolio shift (pp) | Between-cause shift (pp) | Share between-causes (%) | Largest gain | Largest loss |

- **Total** = `sensitivity_index` (½·Σ|Δ fund allocation|).
- **Between-cause** = the cluster SI (auto-detected: `si_cluster` / `cluster_si`
  / `ca_sensitivity_index`, or joined from a separate cause CSV).
- **Share** = between ÷ total, as a percent (`NA` when total ≈ 0).
- **Largest gain / loss** = the most positive / most negative per-fund delta,
  with ties shown comma-separated. Fund slugs are mapped to report names
  (`navigation_fund_general` → "TNF - General") via `FUND_DISPLAY`.

Formatting follows the report's dominant style: integers for |value| ≥ 10, one
decimal below; gains/losses signed with a `pp` suffix.

## Row selection: ranking + the "grow but don't shrink" rule

Each spec chooses how its rows are selected:

- **`select="auto_top"`** — one row per CSV scenario, **re-ranked by total SI
  descending every run** (so if the ranking changes, the table changes). The
  number of rows kept is

      max(floor, number of scenarios with total SI > threshold)

  where `threshold` defaults to **10** and `floor` is, for an in-place table,
  **the table's current row count** in the report (so the table never shrinks
  below what's already published, but grows when more scenarios cross the
  threshold). Override the floor with `min_rows=N`, or the cutoff with
  `threshold=...`. For a not-yet-published table (emit mode) there is no current
  count, so set `min_rows` explicitly (GCR uses `min_rows=8`).

- **`select="editorial"`** (default) — use the explicit `rows` list with your own
  labels/grouping; `sort="total_desc"` still re-ranks them, `sort="none"` keeps
  your order. Use this for parameter sweeps (e.g. time discounts, where the rows
  are a fixed multiplier ladder, not a scenario ranking).

## Usage

```bash
cd sensitivity-analysis/reports

# Markdown previews for every wired table (no .docx touched) — quick to eyeball:
python update_report_tables.py --no-docx

# Full run: update in-place tables in a COPY of the report + emit standalone ones:
python update_report_tables.py
#   -> "Fund-Level Sensitivity Analysis Draft 2 (auto).docx"  (original untouched)
#   -> auto_tables/<name>.md   and   auto_tables/<name>.docx (emit-mode tables)

# Just some tables:
python update_report_tables.py time-discounts gcr-params

# Inspect helpers:
python update_report_tables.py --list-csv gcr-params     # a CSV's columns + detected delta/between cols
python update_report_tables.py --list-doc-tables         # every table in the report with its index + header

# Point at a different report / output path:
python update_report_tables.py --in path/to/report.docx --out path/to/out.docx
```

The original report `.docx` is **never** modified — output always goes to a new
file.

## How a table is matched in the .docx (`mode="inplace"`)

`Locate(header_contains=[...])` finds the table whose header row contains all the
given substrings (case-insensitive). This survives table reordering. If two
tables share header text, fall back to `Locate(index=N)` (use `--list-doc-tables`
to find N). The script keeps the report's existing header wording and only
refreshes the body rows; it clones an existing row's XML to preserve cell
formatting (and to dodge a python-docx crash on tables with fractional column
widths).

## Adding a table (the dictionary entry)

1. `python update_report_tables.py --list-csv <existing-name>` is a handy
   template; first confirm your CSV's columns with
   `python -c "import pandas;print(list(pandas.read_csv('PATH').columns))"`.
2. Add a `TableSpec` to `TABLE_SPECS`. The two patterns:

   **One row per scenario** (like GCR): `rows="auto"` with a `label_map`
   (scenario key → pretty label) and `exclude` (e.g. `baseline`, `noise_check`).

   **Editorial rows** (chosen/relabelled/grouped, like time-discounts): list
   `Row(labels=[...], keys=[[...]])` entries. `labels` fills the label columns;
   `keys` is a list of CSV key tuples — give it more than one to average several
   scenarios into one labelled row (e.g. `All GCR ×100, 1000, 10000`).

3. `columns=[...]` lists the table's columns left→right using the `Col.*`
   helpers (`Col.label("...")`, `Col.total()`, `Col.between()`, `Col.share()`,
   `Col.gain()`, `Col.loss()`). For `inplace` tables, set the `Col` headers to
   match the report exactly — though only the body is rewritten, the headers
   document intent and are used when the same spec is rendered to Markdown.
4. `sort="total_desc"` re-sorts rows by total shift (the report's usual order);
   `sort="none"` keeps your `rows` order (use this when label order is editorial,
   e.g. time-discounts).

## Currently wired

| `name` | mode | source CSV | notes |
|--------|------|-----------|-------|
| `gcr-params` | emit | `gcr-params/outputs/fund/gcr_sensitivity_index.csv` | not yet in the report; paste `auto_tables/gcr-params.docx` in, then switch to `inplace` |
| `time-discounts` | inplace | `time-discounts/outputs/fund/discount_fund_si.csv` | 1e-7 … 0 rows for both discount groups |

## Remaining report tables to wire

All of these have the per-fund delta columns needed for gain/loss. Add a
`TableSpec` for each when ready; the ones flagged "needs label map" require you
to confirm which CSV scenario key each editorial row corresponds to.

| Report table (header starts with…) | Analysis / source CSV | Key column(s) | Notes |
|---|---|---|---|
| `Fund Varied | Total allocation shift…` | across-the-board `outputs/fund/ce_multiplier_si.csv` | `fund_varied`, `multiplier` | between-cause via `cause_csv="across-the-board/outputs/cause/cause_area_si.csv"`; editorial grouping ("All GCR ×100,1000,10000" → 3 keys averaged) |
| `Worldview | Credence shift | Total portfolio shift…` | worldview-sensitivity `outputs/fund/split_credences_index.csv` | `scenario` (+ `worldview`,`bound`,…) | deltas are `<fund>_delta`; between-cause via `cause_csv="worldview-sensitivity/outputs/cause/cause_area_index.csv"`; drop `bound=="single"` rows |
| `Method | Scenario | Total portfolio shift…` | aggregation-methods `outputs/fund/split_credences_index.csv` | `scenario`, `method` | `ca_sensitivity_index` present; `<fund>_delta` |
| `Scenario | Total portfolio shift (pp)…` (moral weights) | moral-weights `outputs/fund/moral_weights_overall_si.csv` | `multiplier` | **needs label map**: rows mix named weight sets (`low_animals`,`sentience_only`,`moderate`,`moderate_high`) with numeric `0.1/0.2/0.5` |
| `GCR and AW slow…` (timing) | ghd-timing-sensitivity (confirm CSV) | `scenario` | confirm between-cause source; `ghd_timing_index.csv` lacks deltas — use `ghd_timing_by_fund.csv` or a fund-SI CSV |
| `Cap at 2.5x budget…` | diminishing-returns `outputs/fund/max_spend_sensitivity_by_fund.csv` | `scenario`, `max_addl_spend_multiplier` | `ca_sensitivity_index`; `<fund>_delta` |
| `Starting Risk Profile | … | Total portfolio shift…` (×2) | risk-aversion `outputs/fund/risk_aversion_summary.csv` | `test` | **needs label map**: two tables (Neutral-start, Baseline-start) drawn from the `test` rows |
