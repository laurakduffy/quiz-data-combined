### Time Discounting

| Scenario | Time discount multiplier | Total portfolio shift | Between-cause portfolio shift | Share of SI is between clusters (%) | Largest gain | Largest loss |
| --- | --- | --- | --- | --- | --- | --- |
| Discount 500+ | 1E-07 | 0.0 | 0.0 | NA | NA | NA |
| Discount 500+ | 1E-08 | 0.0 | 0.0 | NA | NA | NA |
| Discount 500+ | 1E-09 | 1.3 | 1.3 | 100% | EA AWF (+0.6pp) | Sentinel Bio (-0.8pp) |
| Discount 500+ | 1E-10 | 7.5 | 7.5 | 100% | EA AWF (+3.7pp) | Sentinel Bio (-4.5pp) |
| Discount 500+ | 0 | 15 | 15 | 100% | TNF - General (+8.4pp) | Longview AI (-6.4pp) |
| Discount 100-500 and 500+ | 1E-07 | 0.0 | 0.0 | NA | NA | NA |
| Discount 100-500 and 500+ | 1E-08 | 0.0 | 0.0 | NA | NA | NA |
| Discount 100-500 and 500+ | 1E-09 | 1.3 | 1.3 | 100% | EA AWF (+0.6pp) | Sentinel Bio (-0.8pp) |
| Discount 100-500 and 500+ | 1E-10 | 7.5 | 7.5 | 100% | EA AWF (+3.7pp) | Sentinel Bio (-4.5pp) |
| Discount 100-500 and 500+ | 0 | 21 | 21 | 100% | TNF - General (+11pp) | Longview AI (-8.8pp) |
