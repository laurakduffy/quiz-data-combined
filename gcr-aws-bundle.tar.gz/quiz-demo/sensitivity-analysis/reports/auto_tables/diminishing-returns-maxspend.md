### Diminishing Returns — Max Additional Spend

| Scenario | Total portfolio shift (pp) | Between-cause shift (pp) | Share of shift between-causes (%) | Largest gain | Largest loss |
| --- | --- | --- | --- | --- | --- |
| Cap at 2.5x budget | 15 | 14 | 96% | GiveWell (+13pp) | TNF - Cage-free (-7.8pp) |
| Cap at 10x budget | 13 | 5.4 | 41% | TNF - Cage-free (+7.3pp) | TNF - General (-8.2pp) |
| Cap at 7.5x budget | 9.5 | 3.7 | 38% | TNF - Cage-free (+6.5pp) | TNF - General (-4.8pp) |
